# spacex assignmet
Space X Interview Test

Skills used : HTML5, CSS3, Javascript

1) Used javascript fetch function to fetch data from given url
2) Instead of manipulating URL, directly changing data on click of filters
3) Used mobile first approach for responsive design
